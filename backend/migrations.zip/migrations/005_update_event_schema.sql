-- Update Events table schema with new fields

-- Add new columns to events table
ALTER TABLE events 
    ADD COLUMN IF NOT EXISTS client_name TEXT,
    ADD COLUMN IF NOT EXISTS company_name TEXT,
    ADD COLUMN IF NOT EXISTS contact_name TEXT,
    ADD COLUMN IF NOT EXISTS venue TEXT,
    ADD COLUMN IF NOT EXISTS city TEXT,
    ADD COLUMN IF NOT EXISTS head_karigar TEXT,
    ADD COLUMN IF NOT EXISTS manager TEXT;

-- Migrate existing data from old columns to new columns
UPDATE events SET 
    venue = venue_name,
    contact_name = contact_person
WHERE venue IS NULL OR contact_name IS NULL;

-- Mark old columns for deprecation (keep for backward compatibility initially)
-- venue_name and contact_person will be deprecated in a future migration

-- Update comments to document the schema
COMMENT ON COLUMN events.client_name IS 'Name of the client';
COMMENT ON COLUMN events.company_name IS 'Company name of the client';
COMMENT ON COLUMN events.contact_name IS 'Primary contact person name';
COMMENT ON COLUMN events.venue IS 'Event venue name';
COMMENT ON COLUMN events.city IS 'City where the event is held';
COMMENT ON COLUMN events.head_karigar IS 'Head karigar assigned to the event';
COMMENT ON COLUMN events.manager IS 'Manager assigned to the event';
